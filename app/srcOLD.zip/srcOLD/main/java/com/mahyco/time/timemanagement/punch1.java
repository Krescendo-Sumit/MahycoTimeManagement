package com.mahyco.time.timemanagement;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Looper;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.Task;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import static org.apache.http.HttpHeaders.SERVER;

public class punch1 extends AppCompatActivity implements  android.location.LocationListener {

   private CardView btnClick, btnPunchOUT;
    RelativeLayout mainlayout;
    TextView txtText, txtCordinate, txtLocation, txtTime, txtDate, txtDay,txtAccuracy,txtAccuracyTxt;
    TextView txtFlag1, txtTime1, txtDate1;
    public Messageclass msclass;
    public CommonExecution cx;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Config config;
    public String SERVER = "http://cmr.mahyco.com/BreaderDataHandler.ashx";
    private static final String TAG = "LocationActivity";
    private static final long INTERVAL = 1000 * 2;
    private static final long FASTEST_INTERVAL = 1000 * 5;
    String address;
    LocationRequest mLocationRequest;
    LocationCallback mlocationCallback;
    GoogleApiClient mGoogleApiClient;
    Location mCurrentLocation;
    String mLastUpdateTime;
    ImageView gpsBtn;
    ImageView signoutBtn;
    String mDate, mDay;
    databaseHelper databaseHelper1;
    public String userCode;
    ProgressDialog dialog;
    String currentVersion, latestVersion;
    Dialog dialog1;
    private Context context;
    LocationManager locationManager;
    private double longitude;
    private double latitude;
    private FusedLocationProviderClient fusedLocationClient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_punch1);
        msclass = new Messageclass(this);
        btnClick = (CardView) findViewById(R.id.btnPunch);
        btnPunchOUT = (CardView) findViewById(R.id.btnPunchOUT);
        mainlayout = (RelativeLayout) findViewById(R.id.mainlayout);
        txtText = (TextView) findViewById(R.id.txtText);
        txtCordinate = (TextView) findViewById(R.id.txtCordinate);
        txtLocation = (TextView) findViewById(R.id.txtLocation);
        txtTime = (TextView) findViewById(R.id.txtTime);
        txtDate = (TextView) findViewById(R.id.txtDate);
        txtDay = (TextView) findViewById(R.id.txtDay);
        txtFlag1 = (TextView) findViewById(R.id.txtFlag1);
        txtTime1 = (TextView) findViewById(R.id.txtTime1);
        txtDate1 = (TextView) findViewById(R.id.txtDate1);
        txtAccuracy = (TextView) findViewById(R.id.txtAccuracy);
        txtAccuracyTxt = (TextView) findViewById(R.id.txtAccuracyTxt);
        gpsBtn = (ImageView) findViewById(R.id.gpsBtn);
        signoutBtn=(ImageView)findViewById(R.id.signoutBtn);
        databaseHelper1 = new databaseHelper(this);
        msclass = new Messageclass(this);
        cx = new CommonExecution(this);
        config = new Config(this); //Here the context is passing
        dialog = new ProgressDialog(this);
        final MediaPlayer MP = MediaPlayer.create(this, R.raw.mahyco);
        Cursor data1 = databaseHelper1.fetchusercode();
        punch1.setBlinkingTextview(gpsBtn,700,10);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(punch1.this);
        pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        editor = pref.edit();
        this.context=context;
        getCurrentVersion();
        getLocation();
        if (data1.getCount() == 0) {
            //msclass.showMessage("No Data Available... ");
        } else {
            data1.moveToFirst();
            if (data1 != null) {
                do {
                    userCode = data1.getString((data1.getColumnIndex("user_code")));
                } while (data1.moveToNext());
            }
            data1.close();
        }
        isTimeAutomatic(punch1.this);
        boolean value = isTimeAutomatic(this);

        if (value != true) {
            AlertDialog.Builder builder = new AlertDialog.Builder(punch1.this);

            builder.setTitle("Mahyco");
            // builder.setMessage("Observation Saved");
            builder.setMessage("Please Enable Automatic Date and Time. \nWant To Enable It?");

            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {


                @Override
                public void onClick(DialogInterface dialog, int which) {
                    startActivityForResult(new Intent(android.provider.Settings.ACTION_DATE_SETTINGS), 0);
                }
            });

            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                    finish();
                    dialog.dismiss();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        } else {
            //
        }

        showdata();

        gpsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startLocationUpdates();
                updateUI();


            }
        });

        signoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(punch1.this);

                builder.setTitle("Mahyco");
                // builder.setMessage("Observation Saved");
                builder.setMessage("Do you want to sing out?");

                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SharedPreferences pref;
                        SharedPreferences.Editor editor;
                        pref = context.getSharedPreferences("MyPref", 0); // 0 - for private mode
                        editor = pref.edit();
                        editor.clear();
                        editor.commit();
                        Intent openIntent = new Intent(context, login.class);
                        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(openIntent);
                    }
                });

                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();
                        dialog.dismiss();
                    }
                });

                AlertDialog alert = builder.create();
                alert.show();
            }
        });
        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // mp.start();

                if (validation() == true) {

                    try {
                        AlertDialog.Builder builder = new AlertDialog.Builder(punch1.this);

                        builder.setTitle("Mahyco");
                        // builder.setMessage("Observation Saved");
                        builder.setMessage("Do you want to save record?");

                        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            @SuppressLint("WrongConstant")
                            public void onClick(DialogInterface dialog, int which) {

                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                String entrydate = sdf.format(new Date());

                                SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");
                                String entrytime = sdf1.format(new Date());

                                String input = txtDate.getText().toString();
                                String Time = txtTime.getText().toString();
                                String cordinate = txtCordinate.getText().toString();

                                String[] split = input.split("Date: ");
                                String Date = split[1];

                                String[] split1 = Time.split("Time: ");
                                String TimeSplit = split1[1];

                                String[] cordi = cordinate.split("Cordinates: ");
                                String cordinates = cordi[1];

                                boolean result = databaseHelper1.InsertPunchData(userCode, txtLocation.getText().toString(), cordinates,
                                        "IN", Date, entrytime, entrydate);
                                if (result) {
                                    MP.start();
                                    msclass.showMessage("Punch IN data save successfully");
                                    mainlayout.setBackgroundColor(Color.rgb(255, 76, 76));
                                    btnPunchOUT.setVisibility(View.VISIBLE);
                                    btnClick.setVisibility(View.GONE);
                                    updateUI();
                                    dialog.dismiss();
                                    showdata();

                                    if (punch1.CheckNetwork.isInternetAvailable(punch1.this)) //returns true if internet available
                                    {
                                        HR_Data_Upload("HR_Data_Upload");

                                        //do something. loadwebview.
                                    } else {
                                        // Toast.makeText(punch.this,"No Internet Connection",1000).show();
                                    }

                                }
                            }
                        });

                        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                // Do nothing
                                dialog.dismiss();
                            }
                        });

                        AlertDialog alert = builder.create();
                        alert.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            }
        });

        ///Insert Punch OUT
        btnPunchOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // mp.start();

                if (validation() == true) {

                    try {
                        AlertDialog.Builder builder = new AlertDialog.Builder(punch1.this);

                        builder.setTitle("Mahyco");
                        // builder.setMessage("Observation Saved");
                        builder.setMessage("Do you want to save record?");

                        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int which) {

                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                String entrydate = sdf.format(new Date());

                                SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");
                                String entrytime = sdf1.format(new Date());

                                String input = txtDate.getText().toString();
                                String Time = txtTime.getText().toString();
                                String cordinate = txtCordinate.getText().toString();

                                String[] split = input.split("Date: ");
                                String Date = split[1];

                                String[] split1 = Time.split("Time: ");
                                String TimeSplit = split1[1];

                                String[] cordi = cordinate.split("Cordinates: ");
                                String cordinates = cordi[1];

                                boolean result = databaseHelper1.InsertPunchData(userCode, txtLocation.getText().toString(), cordinates,
                                        "OUT", Date, entrytime, entrydate);
                                if (result) {
                                    MP.start();
                                    msclass.showMessage("Punch OUT data save successfully");
                                    mainlayout.setBackgroundColor(Color.rgb(76, 166, 76));
                                    btnPunchOUT.setVisibility(View.GONE);
                                    btnClick.setVisibility(View.VISIBLE);
                                    updateUI();
                                    dialog.dismiss();
                                    showdata();
                                    if (punch1.CheckNetwork.isInternetAvailable(punch1.this)) //returns true if internet available
                                    {
                                        HR_Data_Upload("HR_Data_Upload");

                                        //do something. loadwebview.
                                    } else {
                                        // Toast.makeText(punch.this,"No Internet Connection",1000).show();
                                    }
                                }
                            }
                        });

                        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                // Do nothing
                                dialog.dismiss();
                            }
                        });

                        AlertDialog alert = builder.create();
                        alert.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private void getCurrentVersion() {
        PackageManager pm = this.getPackageManager();
        PackageInfo pInfo = null;

        try {
            pInfo = pm.getPackageInfo(this.getPackageName(), 0);

        } catch (PackageManager.NameNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        currentVersion = pInfo.versionName;

        new punch1.GetLatestVersion().execute();
    }

    private class GetLatestVersion extends AsyncTask<String, String, JSONObject> {

        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected JSONObject doInBackground(String... params) {
            try {
//It retrieves the latest version by scraping the content of current version from play store at runtime
                String urlOfAppFromPlayStore = "https://play.google.com/store/apps/details?id=com.mahyco.time.timemanagement";
                Document doc = Jsoup.connect(urlOfAppFromPlayStore).get();
                latestVersion = doc.getElementsByClass("htlgb").get(6).text();

            } catch (Exception e) {
                e.printStackTrace();

            }

            return new JSONObject();
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            if (latestVersion != null) {
                if (!currentVersion.equalsIgnoreCase(latestVersion)) {
                    if (!isFinishing()) { //This would help to prevent Error : BinderProxy@45d459c0 is not valid; is your activity running? error
                        showUpdateDialog();
                    } else {
//                        new Thread(new Runnable() {
//                            @Override
//                            public void run() {
//                                dowork();
//                                startapp();
//                                finish();
//                            }
//                        }).start();

                    }
                }
            } else
                // background.start();
                super.onPostExecute(jsonObject);
        }
    }

    private void showUpdateDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("A New Update is Available");
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse
                        ("https://play.google.com/store/apps/details?id=com.mahyco.time.timemanagement")));
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //background.start();
            }
        });

        builder.setCancelable(false);
        dialog1 = builder.show();
    }
    public static void setBlinkingTextview(ImageView tv, long milliseconds, long offset) {
        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(milliseconds); //You can manage the blinking time with this parameter
        anim.setStartOffset(offset);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        tv.startAnimation(anim);
    }
    public void showdata() {
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String formattedDate = df.format(c);
        Cursor data = databaseHelper1.Data();

        if (data.getCount() == 0) {
            // msclass.showMessage("No Data Available... ");
        } else {
            data.moveToFirst();
            if (data != null) {
                try {


                    do {
                        txtDate1.setText("Date   :  " + (data.getString(data.getColumnIndex("punchdate"))));
                        txtTime1.setText("Time   :  " + (data.getString(data.getColumnIndex("punchtime"))));
                        txtFlag1.setText("In/Out :  " + (data.getString(data.getColumnIndex("att_flag"))) + "\n");

                        String lastdate = (data.getString(data.getColumnIndex("punchdate")));

                        if ((data.getString(data.getColumnIndex("att_flag"))).equals("IN")) {
                            mainlayout.setBackgroundColor(Color.rgb(255, 76, 76));
                            btnPunchOUT.setVisibility(View.VISIBLE);
                            btnClick.setVisibility(View.GONE);
                            updateUI();
                        } else if ((data.getString(data.getColumnIndex("att_flag"))).equals("OUT")) {
                            mainlayout.setBackgroundColor(Color.rgb(76, 166, 76));
                            btnPunchOUT.setVisibility(View.GONE);
                            btnClick.setVisibility(View.VISIBLE);
                            updateUI();
                        } else {
                            //
                        }

                        if (lastdate.equals(formattedDate)) {

                        } else {
                            mainlayout.setBackgroundColor(Color.rgb(76, 166, 76));
                            btnPunchOUT.setVisibility(View.GONE);
                            btnClick.setVisibility(View.VISIBLE);
                            updateUI();
                        }
                    } while (data.moveToNext());

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
            data.close();
        }
    }

    private boolean validation() {
        boolean flag = true;
        if (txtCordinate.getText().equals("")) {
            msclass.showMessage("Poor GPS connectivity\nTry again later!");
            return false;
        }
        if (txtLocation.getText().equals("")) {
            msclass.showMessage("Poor GPS connectivity\nTry again later!");
            return false;
        }
        return true;
    }

    public static boolean isTimeAutomatic(Context c) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return Settings.Global.getInt(c.getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
        } else {
            return android.provider.Settings.System.getInt(c.getContentResolver(), android.provider.Settings.System.AUTO_TIME, 0) == 1;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart fired ..............");
        mGoogleApiClient.connect();
    }

    protected void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
    }

    public void getLocation() {
        try {
            locationManager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, (android.location.LocationListener) this);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, (android.location.LocationListener) this);
            //locationManager.getLastKnownLocation(locationManager.GPS_PROVIDER);
        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onLocationChanged(Location location) {
        mCurrentLocation = location;
        mLastUpdateTime = DateFormat.getTimeInstance().format(new Date());
        float accuracy=  mCurrentLocation.getAccuracy();

        if(accuracy==0.0f){
            txtAccuracy.setText( String.valueOf(accuracy));
            txtAccuracy.setVisibility(View.INVISIBLE);
            txtAccuracyTxt.setVisibility(View.INVISIBLE);
        }else {
            txtAccuracy.setText( accuracy+"m");
            txtAccuracy.setVisibility(View.VISIBLE);
            txtAccuracyTxt.setVisibility(View.VISIBLE);
        }
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String formattedDate = df.format(c);

        SimpleDateFormat sdfm = new SimpleDateFormat("EEEE");

        Date d = new Date();
        String day=sdfm.format(d);
        mDay=day;
        mDate=formattedDate;
        updateUI();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }


    private void updateUI() {
        Log.d(TAG, "UI update initiated .............");
        if (null != mCurrentLocation) {
            String lat = String.valueOf(mCurrentLocation.getLatitude());
            String lng = String.valueOf(mCurrentLocation.getLongitude());
            txtDate.setText("Date: " + mDate);
            txtDay.setText("Day: " + mDay);
            txtTime.setText("Time: " + mLastUpdateTime);
            txtCordinate.setText("Cordinates: " + lat + "," + lng);

            try {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocation(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude(), 1);
                txtLocation.setText("" + addresses.get(0).getAddressLine(0) + "");
            } catch (Exception e) {

            }
        } else {
            Log.d(TAG, "location is null ...............");
        }
    }


    public void onProviderDisabled(String provider) {
        Toast.makeText(this, "Please Enable GPS", Toast.LENGTH_SHORT).show();
        final Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(intent);
    }

    // To Upload Obseervation On server
    public   void HR_Data_Upload(String HR_Data_Upload)
    {
        if(config.NetworkConnection()) {
            dialog.setMessage("Loading....");
            dialog.show();
            String str= null;
            // str = cx.new MDOMasterData(1, txtUsername.getText().toString(), txtPassword.getText().toString()).execute().get();
            String searchQuery = "select  *  from punchdata where flag='0'";
            Cursor cursor = databaseHelper1.getReadableDatabase().rawQuery(searchQuery, null );
            int count=cursor.getCount();

            if (count > 0) {

                try {
                    byte[] objAsBytes = null;//new byte[10000];
                    JSONObject object = new JSONObject();
                    try {
                        object.put("Table1", databaseHelper1.getResults(searchQuery));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        objAsBytes = object.toString().getBytes("UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    dialog.setMessage("Loading. Please wait...");
                    dialog.show();
                    str= new punch1.UploadDataServer(HR_Data_Upload,objAsBytes).execute(SERVER).get();
                    //End
                    cursor.close();
                    //End
                    if(str.contains("True")) {

                        dialog.dismiss();
                        // msclass.showMessage("Records Uploaded successfully");
                        String searchQuery1 = "update punchdata set flag = '1' where flag='0'";
                        databaseHelper1.runQuery(searchQuery1);
                    }
                    else
                    {
                        msclass.showMessage(str);
                        dialog.dismiss();
                    }

                }
                catch (Exception ex)
                {   dialog.dismiss();
                    msclass.showMessage(ex.getMessage());


                }
            }
            else
            {   dialog.dismiss();
                //msclass.showMessage("Data not available for Uploading ");
                dialog.dismiss();

            }

        }
        else
        {
            //msclass.showMessage("Internet network not available.");
            dialog.dismiss();
        }
        //dialog.dismiss();
    }
    //

    public class UploadDataServer extends AsyncTask<String, String, String> {

        byte[] objAsBytes;
        String Imagestring1;
        String Imagestring2;
        String ImageName;
        String Funname;
        public UploadDataServer( String Funname, byte[] objAsBytes) {

            //this.IssueID=IssueID;
            this.objAsBytes=objAsBytes;
            this.Imagestring1 =Imagestring1;
            this.Imagestring2 =Imagestring2;
            this.ImageName=ImageName;
            this.Funname=Funname;

        }
        protected void onPreExecute() {}
        @Override
        protected String doInBackground(String... urls) {

            // encode image to base64 so that it can be picked by saveImage.php file
            String encodeImage = Base64.encodeToString(objAsBytes,Base64.DEFAULT);
            //showMessage(encodeImage);
            HttpClient httpclient = new DefaultHttpClient();
            StringBuilder builder = new StringBuilder();
            List<NameValuePair> postParameters = new ArrayList<NameValuePair>(2);
            postParameters.add(new BasicNameValuePair("from",Funname));
            postParameters.add(new BasicNameValuePair("encodedData", encodeImage));

            String Urlpath=urls[0];

            // String Urlpath=urls[0]+"?action=2&farmerid="+userID+"&croptype="+croptype+"&imagename=Profile.png&issueDescription="+IssueDesc+"&issueid=1";

            HttpPost httppost = new HttpPost(Urlpath);
            httppost.addHeader("Content-type", "application/x-www-form-urlencoded");

            try {
                httppost.setEntity(new UrlEncodedFormEntity(postParameters));
                UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(postParameters);
                httppost.setEntity(formEntity);

                HttpResponse response = httpclient.execute(httppost);
                StatusLine statusLine = response.getStatusLine();
                int statusCode = statusLine.getStatusCode();
                if (statusCode == 200) {
                    HttpEntity entity = response.getEntity();
                    InputStream content = entity.getContent();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(content));

                    String line;
                    while ((line = reader.readLine()) != null) {
                        builder.append(line).append("\n");
                    }

                }
            }
            catch (ClientProtocolException e) {
                e.printStackTrace();
                msclass.showMessage(e.getMessage().toString());
                dialog.dismiss();

            }
            catch (Exception e) {
                e.printStackTrace();
                msclass. showMessage(e.getMessage().toString());
                dialog.dismiss();
            }

            //dialog.dismiss();
            return builder.toString();
        }
        protected void onPostExecute(String result) {
            String weatherInfo="Weather Report  is: \n";
            try{
                String resultout=result.trim();
                if(resultout.equals("True")) {
                    // msclass.showMessage("Data uploaded successfully.");

                    if(Funname.equals("HR_Data_Upload")) {

                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        Date d=new Date();
                        String strdate=dateFormat.format(d);

                    }

                }
                else
                {
                    msclass.showMessage(result+"error");
                }

                // dialog.dismiss();


            }

            catch (Exception e) {
                e.printStackTrace();
                msclass.showMessage(e.getMessage().toString());
                dialog.dismiss();
            }

        }
    }

    public static class CheckNetwork {


        private static final String TAG = punch1.CheckNetwork.class.getSimpleName();
        public static boolean isInternetAvailable(Context context)
        {
            NetworkInfo info = (NetworkInfo) ((ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();

            if (info == null)
            {
                Log.d(TAG,"no internet connection");
                return false;
            }
            else
            {
                if(info.isConnected())
                {
                    Log.d(TAG," internet connection available...");
                    return true;
                }
                else
                {
                    Log.d(TAG," internet connection");
                    return true;
                }

            }
        }
    }
}

