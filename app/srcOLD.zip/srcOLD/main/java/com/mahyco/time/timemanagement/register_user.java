package com.mahyco.time.timemanagement;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

public class register_user extends AppCompatActivity {
    public EditText txtEnterName, txtEnterEmpCode, txtIMEI, txtEnterotp, txtEnterEmpMobile;
    public CardView btnLogin;
    public TextView txtTerms, txtotp1;
    public Messageclass msclass;
    public CommonExecution cx;
    public CheckBox chk;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Config config;
    databaseHelper databaseHelper1;
    private boolean isCheckedValue;
    //public Button btnLogin;
    ProgressDialog dialog;
    TelephonyManager tel;
    String  imei="";
    String  mobilenumber="";
    String usercode="";
    String  username="";
    String password="";
   // SharedPreferences pref;
    //SharedPreferences.Editor editor;
    Prefs mPref;
    Context context;
    @SuppressLint("HardwareIds")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);
        databaseHelper1 = new databaseHelper(this);
        msclass = new Messageclass(this);
        cx = new CommonExecution(this);
        mPref=Prefs.with(this);
        pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        editor = pref.edit();
        context = this;
        config = new Config(this); //Here the context is passing
        dialog = new ProgressDialog(this);
        btnLogin = (CardView) findViewById(R.id.btnLogin);
        txtEnterName = (EditText) findViewById(R.id.txtEnterName);
        txtEnterEmpCode = (EditText) findViewById(R.id.txtEnterEmpCode);
        txtIMEI = (EditText) findViewById(R.id.txtIMEI);
        txtEnterotp = (EditText) findViewById(R.id.txtEnterotp);
        txtEnterEmpMobile = (EditText) findViewById(R.id.txtEnterEmpMobile);
        txtTerms = (TextView) findViewById(R.id.txtTerms);
        chk = (CheckBox) findViewById(R.id.chk);
        txtotp1 = (TextView) findViewById(R.id.txtotp1);

        btnLogin.setEnabled(false);

        pref = this.getSharedPreferences("MyPref", 0); // 0 - for private mode
        editor = pref.edit();
        txtTerms.setText(Html.fromHtml("<u>Terms and Conditions</u>"));
        btnLogin.setCardBackgroundColor(Color.rgb(153, 214, 184));
        tel = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);


//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            String imei = tel.getImei();
//            txtIMEI.setText(imei);
//
//        } else {
//            String imei = tel.getDeviceId();
//            txtIMEI.setText(imei);
//
//        }


        getUUID();


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validation() == true) {
                    //dialog.setMessage("Loading. Please wait...");
                    //dialog.show();

                    String searchQuery1 = "delete from UserMaster ";
                    databaseHelper1.runQuery(searchQuery1);
                    UserRegisteration();
                }
            }
        });

        chk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    btnLogin.setEnabled(true);
                    txtotp1.setEnabled(true);
                    btnLogin.setCardBackgroundColor(Color.rgb(0, 154, 78));
                } else {
                    btnLogin.setEnabled(false);
                    txtotp1.setEnabled(false);
                    btnLogin.setCardBackgroundColor(Color.rgb(153, 214, 184));
                }
            }
        });

        txtTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(register_user.this);
                LayoutInflater inflater = register_user.this.getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.alert, null);
                dialogBuilder.setView(dialogView);
                dialogBuilder.setPositiveButton("OK", null);

                AlertDialog alertDialog = dialogBuilder.create();

                alertDialog.show();
            }
        });
    }

    public void getUUID() {


        String uuid = pref.getString("uuid", "");

        String deviceId;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_PHONE_STATE, android.Manifest.permission.READ_PHONE_STATE}, 101);
            return;
        }
        if (tel.getDeviceId() != null) {
            deviceId = tel.getDeviceId();
            txtIMEI.setText(deviceId);
            editor.putString("uuid", deviceId);
            editor.apply();

        } else {


            if (uuid.isEmpty()) {
                deviceId = UUID.randomUUID().toString();
                editor.putString("uuid", deviceId);
                editor.commit();
                txtIMEI.setText(deviceId);
            } else {
                txtIMEI.setText(uuid);
            }


        }


    }

    private boolean validation() {
        boolean flag = true;
        if (txtEnterName.getText().length() == 0) {
            msclass.showMessage("Please Enter User Name ");
            return false;

        }
        if (txtEnterEmpCode.getText().length() == 0) {
            msclass.showMessage("Please Enter Valid Emp Code");
            return false;
        }

        if (txtIMEI.getText().length() == 0) {
            msclass.showMessage("IMEI number can't be blank");
            return false;
        }
        if(txtEnterEmpMobile.getText().length()!=10)
        {
            msclass.showMessage(("Please Enter valid Mobile Number"));
            return false;
        }
        if (txtEnterotp.getText().length() == 0) {
            msclass.showMessage("Please Enter Password To Set");
            return false;
        }
        return true;
    }

    private boolean UserRegisteration() {
        if (config.NetworkConnection()) {
            //dialog.setMessage("Loading....");
            //dialog.show();
            String str = null;
            String strAuthToken= null;
            String token="";
            boolean fl = false;
            try {
                imei = txtIMEI.getText().toString();
                mobilenumber = txtEnterEmpMobile.getText().toString();
                username=txtEnterName.getText().toString();
                usercode=txtEnterEmpCode.getText().toString();
                password=txtEnterotp.getText().toString();
                try {
                    strAuthToken = new GetAuthToken(txtEnterEmpCode.getText().toString(), txtEnterotp.getText().toString()).execute().get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                JSONObject jsonObject = null;

                jsonObject = new JSONObject(strAuthToken);
                if (jsonObject.has("access_token")) {
                    token = jsonObject.get("access_token").toString();
                    if (token != null && token != "") {
                        try {
                            mPref.save(AppConstant.ACCESS_TOKEN_TAG, token);
                            mPref.save(AppConstant.USER_CODE_TAG, txtEnterEmpCode.getText().toString());

                            //Call
                            //str = cx.new BreederMasterData(txtEnterEmpCode.getText().toString(), txtIMEI.getText().toString(),
                                  //  txtEnterotp.getText().toString(), txtEnterEmpMobile.getText().toString()).execute().get();
                                 str= new Userverify("Hr_veriftyuser", context).execute().get();



                        } catch (ExecutionException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        if (str.contains("False")) {
                            msclass.showMessage("User already register");
                            dialog.dismiss();
                        } else if (str.contains("NotAvailable")) {
                            msclass.showMessage("User not available");
                        } else {
                            // msclass.showMessage(str);
                            JSONObject object = new JSONObject(str);
                            JSONArray jArray = object.getJSONArray("Table");

                            for (int i = 0; i < jArray.length(); i++) {

                                JSONObject jObject = jArray.getJSONObject(0);
                                //if(jObject.getString("IMEI").toString().equals(msclass.getDeviceIMEI())) {
                                 databaseHelper1.deleledata("UserMaster", "");
                                fl = databaseHelper1.InsertUserRegistration(jObject.getString("usercode").toString().toUpperCase(),
                                        jObject.getString("username").toString(), jObject.getString("user_imei").toString(),
                                        jObject.getString("user_pwd").toString());
                                //editor.putString("Displayname", jObject.getString("username").toString());
                            }
                            //  editor.putString("usercode", txtEnterEmpCode.getText().toString());
                            //  editor.commit();

                            if (fl == true) {
                                msclass.showMessage("User registration successfully");
                                dialog.dismiss();
                                txtEnterotp.setText("");
                                txtEnterEmpCode.setText("");
                                Intent intent = new Intent(getApplicationContext(), login.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                return true;
                                // finish();

                            } else {
                                msclass.showMessage("Registration  not done");
                                return false;
                            }
                        }
                    }

                }
            }
                   catch (JSONException e) {
                    e.printStackTrace();
                }





        }

                else {
            msclass.showMessage("Internet network not available.");
            dialog.dismiss();
            return false;
        }
        return true;
    }
    /**
     * <p>Method to get the access token from API</p>
     */
    public synchronized String sycHrVerifyuser(JSONObject jsonObject) {

        return HttpUtils.POSTJSON(Constants.HR_VerifyUser,jsonObject,mPref.getString(AppConstant.ACCESS_TOKEN_TAG,""));
    }
    public class GetAuthToken extends AsyncTask<String, String, String>
    {
        private String username;
        private String password;

        public GetAuthToken(String username ,String password){
            this.username = username;
            this.password = password;
        }

        @Override
        protected String doInBackground(String... strings) {
            List<NameValuePair> postParameters = new ArrayList<NameValuePair>(2);
            postParameters.add(new BasicNameValuePair("grant_type", "password"));
            postParameters.add(new BasicNameValuePair("username", username));
            postParameters.add(new BasicNameValuePair("password",password));
            postParameters.add(new BasicNameValuePair("imei",imei));
            postParameters.add(new BasicNameValuePair("mobilenumber",mobilenumber));

            return HttpUtils.POST(Constants.GetToken,postParameters);
        }


        protected void onPostExecute(String result) {

            Log.d("result", result);
        }

    }

     public  String  callHrVerify()
     {
String str="";
         JSONObject jsonObject = new JSONObject();
         JSONObject jsonObjectreq = new JSONObject();
         try {
             jsonObjectreq.put("usercode",usercode);
             jsonObjectreq.put("username",username);
             jsonObjectreq.put("imei_number",imei);
             jsonObjectreq.put("mobile_number",mobilenumber);
             jsonObjectreq.put("user_pwd",password);
             jsonObject.put("Table",jsonObjectreq);
            str= sycHrVerifyuser(jsonObject);
         } catch (JSONException e) {
             e.printStackTrace();
         }

      return str;

     }
    //** call  Hr _user verify APi
    private class Userverify  extends AsyncTask<String, String, String> {
        private ProgressDialog progressDailog;

        public Userverify(String Funname, Context context) {
        }

        protected void onPreExecute() {
            progressDailog = new ProgressDialog(context);
            progressDailog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDailog.setCanceledOnTouchOutside(false);
            progressDailog.setCancelable(false);
            progressDailog.setMessage("Data Uploading");
            progressDailog.show();
        }

        @Override
        protected String doInBackground(String... urls) {

            return callHrVerify();

        }

        protected void onPostExecute(String result) {

            if (progressDailog != null) {
                progressDailog.dismiss();
            }
            //redirecttoRegisterActivity(result);
            //Staet
            /*try {
                String resultout = result.trim();
                Log.d("Response", resultout);
                JSONObject jsonObject = new JSONObject(resultout);
                if (jsonObject.has("success")) {
                    if (Boolean.parseBoolean(jsonObject.get("success").toString())) {



                    } else {

                    }

                } else {

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
*/
            //end


        }

    }

}
