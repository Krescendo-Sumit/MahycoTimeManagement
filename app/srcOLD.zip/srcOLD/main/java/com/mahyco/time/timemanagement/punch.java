package com.mahyco.time.timemanagement;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsStatusCodes;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class punch extends AppCompatActivity implements
        LocationListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, ResultCallback {
    private CardView btnClick, btnPunchOUT;
    RelativeLayout mainlayout;
    TextView txtText, txtCordinate, txtLocation, txtTime, txtDate, txtDay,txtAccuracy,txtAccuracyTxt;
    TextView txtFlag1, txtTime1, txtDate1;
    public Messageclass msclass;
    public CommonExecution cx;
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    Config config;
    public String SERVER = "http://cmr.mahyco.com/BreaderDataHandler.ashx";
    private static final String TAG = "LocationActivity";
//    private static final long INTERVAL = 1000 * 2;
//    private static final long FASTEST_INTERVAL = 1000 * 5;
    private static final long INTERVAL = 1000;
    private static final long FASTEST_INTERVAL = 1000;
    String address;
    LocationRequest mLocationRequest;
    LocationCallback mlocationCallback;
    GoogleApiClient mGoogleApiClient;
    Location mCurrentLocation;
    String mLastUpdateTime;
    ImageView gpsBtn;
    String mDate, mDay;
    databaseHelper databaseHelper1;
    public String userCode;
    ProgressDialog dialog;
    String currentVersion, latestVersion;
    Dialog dialog1;
    private Context context;
    private FusedLocationProviderClient fusedLocationClient;
    private CardView btnlogout,btnclose;
    Spinner spLocation;
    protected static final String TAG1 = "LocationOnOff";
    int REQUEST_CHECK_SETTINGS = 100;
    private GoogleApiClient googleApiClient;
    final static int REQUEST_LOCATION = 199;
    LinearLayout  worklinerId;
     Dialog dialogpopup;
    Prefs mPref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_punch);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        spLocation=(Spinner)findViewById(R.id.spLocation);
        msclass = new Messageclass(this);
        mPref=Prefs.with(this);
        btnClick = (CardView) findViewById(R.id.btnPunch);
        btnPunchOUT = (CardView) findViewById(R.id.btnPunchOUT);
        mainlayout = (RelativeLayout) findViewById(R.id.mainlayout);
        txtText = (TextView) findViewById(R.id.txtText);
        txtCordinate = (TextView) findViewById(R.id.txtCordinate);
        txtLocation = (TextView) findViewById(R.id.txtLocation);
        txtTime = (TextView) findViewById(R.id.txtTime);
        txtDate = (TextView) findViewById(R.id.txtDate);
        txtDay = (TextView) findViewById(R.id.txtDay);
        txtFlag1 = (TextView) findViewById(R.id.txtFlag1);
        txtTime1 = (TextView) findViewById(R.id.txtTime1);
        txtDate1 = (TextView) findViewById(R.id.txtDate1);
        txtAccuracy = (TextView) findViewById(R.id.txtAccuracy);
        txtAccuracyTxt = (TextView) findViewById(R.id.txtAccuracyTxt);
        gpsBtn = (ImageView) findViewById(R.id.gpsBtn);
        btnlogout=(CardView)findViewById(R.id.btnlogout);
        btnclose=(CardView)findViewById(R.id.btnclose);

        databaseHelper1 = new databaseHelper(this);
        worklinerId=(LinearLayout) findViewById(R.id.worklinerId);
        msclass = new Messageclass(this);
        cx = new CommonExecution(this);
        config = new Config(this); //Here the context is passing
        dialog = new ProgressDialog(this);
        final MediaPlayer MP = MediaPlayer.create(this, R.raw.mahyco);
        Cursor data1 = databaseHelper1.fetchusercode();
        punch.setBlinkingTextview(gpsBtn,700,10);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(punch.this);
        pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        editor = pref.edit();
        this.context=this;

        getCurrentVersion();
        if (data1.getCount() == 0) {
        } else {
            data1.moveToFirst();
            if (data1 != null) {
                do {
                    userCode = data1.getString((data1.getColumnIndex("user_code")));
                } while (data1.moveToNext());
            }
            data1.close();
        }
        // 22-05-2020
        if (userCode.length()==0)
        {
            userCode=pref.getString("UserID", null);
        }
        isTimeAutomatic(punch.this);
        boolean value = isTimeAutomatic(this);
        if (value != true) {
            AlertDialog.Builder builder = new AlertDialog.Builder(punch.this);
            builder.setTitle("Mahyco");
            // builder.setMessage("Observation Saved");
            builder.setMessage("Please Enable Automatic Date and Time. \nWant To Enable It?");

            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {


                @Override
                public void onClick(DialogInterface dialog, int which) {
                    startActivityForResult(new Intent(android.provider.Settings.ACTION_DATE_SETTINGS), 0);
                }
            });
            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                    finish();
                    dialog.dismiss();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        } else {
            //
        }
        //final MediaPlayer mp = MediaPlayer.create(this, R.raw.gtm_analytics);
        Log.d(TAG, "onCreate ..............................." + isTimeAutomatic(punch.this));
        //show error dialog if GoolglePlayServices not available
        if (!isGooglePlayServicesAvailable()) {
            finish();
        }
        createLocationRequest();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
        ///Insert Punch In
        showdata();

        gpsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startLocationUpdates();
                updateUI();


            }
        });

        btnclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(punch.this);

                builder.setTitle("Mahyco");
                // builder.setMessage("Observation Saved");
                builder.setMessage("Do you want to sing out?");

                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SharedPreferences pref;
                        SharedPreferences.Editor editor;
                        pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
                        editor = pref.edit();
                        editor.clear();
                        editor.commit();
                        Intent openIntent = new Intent(getApplicationContext(), login.class);
                        openIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(openIntent);
                    }
                });

                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();
                        dialog.dismiss();
                    }
                });

                AlertDialog alert = builder.create();
                alert.show();
            }
        });


        btnClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // mp.start();
                if (validation() == true) {

                    GeneralMaster pp = (GeneralMaster) spLocation.getSelectedItem();

                      if(pp.Code().contains("0") )
                      {
                         msclass.showMessage("Please select work location");
                         return;
                      }
                    try {
                        AlertDialog.Builder builder = new AlertDialog.Builder(punch.this);

                        builder.setTitle("Mahyco");
                        // builder.setMessage("Observation Saved");
                        builder.setMessage("Do you want to save record?");

                        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            @SuppressLint("WrongConstant")
                            public void onClick(DialogInterface dialog, int which) {

                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                String entrydate = sdf.format(new Date());

                                SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");
                                String entrytime = sdf1.format(new Date());

                                String input = txtDate.getText().toString();
                                String Time = txtTime.getText().toString();
                                String cordinate = txtCordinate.getText().toString();

                                String[] split = input.split("Date: ");
                                String Date = split[1];

                                String[] split1 = Time.split("Time: ");
                                String TimeSplit = split1[1];

                                String[] cordi = cordinate.split("Cordinates: ");
                                String cordinates = cordi[1];

                                boolean result = databaseHelper1.InsertPunchData(userCode, txtLocation.getText().toString(), cordinates,
                                        "IN", Date, entrytime, entrydate);
                                if (result) {
                                   MP.start();
                                    msclass.showMessage("Punch IN data save successfully");
                                    mainlayout.setBackgroundColor(Color.rgb(255, 76, 76));
                                    btnPunchOUT.setVisibility(View.VISIBLE);
                                    btnClick.setVisibility(View.GONE);
                                    worklinerId.setVisibility(View.GONE);
                                    updateUI();
                                    dialog.dismiss();
                                    showdata();

                                    if (CheckNetwork.isInternetAvailable(punch.this)) //returns true if internet available
                                    {
                                        HR_Data_Upload("HR_Data_UploadNew");

                                        //do something. loadwebview.
                                    } else {
                                        // Toast.makeText(punch.this,"No Internet Connection",1000).show();
                                    }

                                }
                            }
                        });

                        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                // Do nothing
                                dialog.dismiss();
                            }
                        });

                        AlertDialog alert = builder.create();
                        alert.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        ///Insert Punch OUT
        btnPunchOUT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // mp.start();

                if (validation() == true) {

                    try {
                        AlertDialog.Builder builder = new AlertDialog.Builder(punch.this);

                        builder.setTitle("Mahyco");
                        // builder.setMessage("Observation Saved");
                        builder.setMessage("Do you want to save record?");

                        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int which) {

                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                String entrydate = sdf.format(new Date());

                                SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");
                                String entrytime = sdf1.format(new Date());

                                String input = txtDate.getText().toString();
                                String Time = txtTime.getText().toString();
                                String cordinate = txtCordinate.getText().toString();

                                String[] split = input.split("Date: ");
                                String Date = split[1];

                                String[] split1 = Time.split("Time: ");
                                String TimeSplit = split1[1];

                                String[] cordi = cordinate.split("Cordinates: ");
                                String cordinates = cordi[1];

                                boolean result = databaseHelper1.InsertPunchData(userCode, txtLocation.getText().toString(), cordinates,
                                        "OUT", Date, entrytime, entrydate);
                                if (result) {
                                    MP.start();
                                    msclass.showMessage("Punch OUT data save successfully");
                                    mainlayout.setBackgroundColor(Color.rgb(76, 166, 76));
                                    btnPunchOUT.setVisibility(View.GONE);
                                    btnClick.setVisibility(View.VISIBLE);
                                    spLocation.setSelection(0);
                                    updateUI();
                                    dialog.dismiss();
                                    showdata();
                                    if (CheckNetwork.isInternetAvailable(punch.this)) //returns true if internet available
                                    {
                                        HR_Data_Upload("HR_Data_UploadNew");

                                        //do something. loadwebview.
                                    } else {
                                        // Toast.makeText(punch.this,"No Internet Connection",1000).show();
                                    }
                                }
                            }
                        });

                        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                // Do nothing
                                dialog.dismiss();
                            }
                        });

                        AlertDialog alert = builder.create();
                        alert.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        spLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                GeneralMaster gm = (GeneralMaster) parent.getSelectedItem();
                try {


                   /* JSONObject object = new JSONObject();
                    String searchQuery2 = "select * from MDO_tagRetailerList where mobileno ='"+mobileno+"' ";
                    object.put("Table1", mDatabase.getResults( searchQuery2));
                    JSONArray jArray = object.getJSONArray("Table1");//new JSONArray(result);*/

                    if (gm.Code().contains("2") )
                    {


                        callHealthPOP();
                        /*
                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(punch.this);
                        // Setting Dialog Title
                        alertDialog.setTitle("TIME MANAGEMENT");
                        // Setting Dialog Message
                        alertDialog.setMessage("Health Declaration Form . ");
                        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int which) {




                            }


                        });


                        AlertDialog alert = alertDialog.create();
                        alert.show();
                        final Button positiveButton = alert.getButton(AlertDialog.BUTTON_POSITIVE);
                        LinearLayout.LayoutParams positiveButtonLL = (LinearLayout.LayoutParams) positiveButton.getLayoutParams();
                        positiveButtonLL.weight = 10;
                        positiveButtonLL.gravity = Gravity.CENTER;
                        positiveButton.setLayoutParams(positiveButtonLL);
                        */
                        //end




                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                {


                    // BindRetailer(taluka);


                }

                // Toast.makeText(MobileVerify.this, "Country ID: "+gm.Code()+",  Country Name : "+gm.Desc(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                //  Toast.makeText(MobileVerify.this,"gngvnv", Toast.LENGTH_LONG).show();
            }
        });
        BindIntialData();
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if(null != dialogpopup)
                dialogpopup.dismiss();
            spLocation.setSelection(0);
        }
        return super.onKeyDown(keyCode, event);
    }

    private  void bindSP(Spinner sp) {

        try {
            sp.setAdapter(null);
            //List<GeneralMaster> Croplist = new ArrayList<GeneralMaster>();
            List<GeneralMaster> Croplist = new ArrayList<GeneralMaster>();
            Croplist.add(new GeneralMaster("0", "CHOOSE"));
            Croplist.add(new GeneralMaster("1", "YES"));
            Croplist.add(new GeneralMaster("2", "NO"));


            // Initializing an ArrayAdapter
          //  ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
            //        this,R.layout.spinner_item,adapter
           // );
           // spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item);
            ArrayAdapter<GeneralMaster> adapter = new ArrayAdapter<GeneralMaster>
                    (this, android.R.layout.simple_spinner_dropdown_item, Croplist);
            //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);




            sp.setAdapter(adapter);
            sp.setSelection(1);


        }
        catch (Exception ex) {
            Toast.makeText(context, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }
    public void callHealthPOP()
    {
        try
        {
            Date c = Calendar.getInstance().getTime();
            SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
            String formattedDate = df.format(c);
            boolean flag = false;

          // final Dialog
             dialogpopup = new Dialog(context);

            dialogpopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialogpopup.setContentView(R.layout.healthform);

            dialogpopup.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            dialogpopup.setOnKeyListener(new Dialog.OnKeyListener() {
                @Override
                public boolean onKey(DialogInterface arg0, int keyCode, KeyEvent event) {
                    // TODO Auto-generated method stub
                    if (keyCode == KeyEvent.KEYCODE_BACK) {
                        spLocation.setSelection(0);
                        //finish();
                    }
                    return true;
                }
            });

           /* final Dialog dialogpopup = new Dialog(context, android.R.style.Theme_Light);
            dialogpopup.requestWindowFeature(Window.FEATURE_NO_TITLE);
           // dialogpopup=new Dialog(punch.this,android.R.style.Theme_Black_NoTitleBar_Fullscreen);
            dialogpopup.setContentView(R.layout.healthform);
            */
             dialogpopup.show();



           // final Dialog dialog = new Dialog(context);
           /// dialog.setContentView(R.layout.healthform);


             /* s.postDelayed(new Runnable() {
                public void run() {
                    s.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
                }
            }, 100L); */
          //  final LinearLayout tblLayout = (LinearLayout)dialog.findViewById(R.id.li1);
            // TableRow row0 = (TableRow)tblLayout.getChildAt(0);
            //TableRow row = (TableRow)tblLayout.getChildAt(1);
            final Spinner sp1 = (Spinner) dialogpopup.findViewById(R.id.sp1);
           final Spinner sp2 = (Spinner) dialogpopup.findViewById(R.id.sp2);
            final Spinner sp3 = (Spinner) dialogpopup.findViewById(R.id.sp3);
            final  Spinner sp4 = (Spinner) dialogpopup.findViewById(R.id.sp4);
            final Spinner sp5 = (Spinner) dialogpopup.findViewById(R.id.sp5);
            final Spinner sp6 = (Spinner) dialogpopup.findViewById(R.id.sp6);
            final Spinner sp7 = (Spinner) dialogpopup.findViewById(R.id.sp7);
            final CheckBox chk = (CheckBox) dialogpopup.findViewById(R.id.chk);

            bindSP(sp1);
            bindSP(sp2);
            bindSP(sp3);
            bindSP(sp4);
            bindSP(sp5);
            bindSP(sp6);
            bindSP(sp7);
            Button btnPunchIn = (Button) dialogpopup.findViewById(R.id.btnPunchIn);
             EditText txt8 = (EditText)dialogpopup.findViewById(R.id.txt8);

              txt8.setText(formattedDate);
            txt8.setEnabled(false);
            ImageView imgclose = (ImageView) dialogpopup.findViewById(R.id.imgclose);
            imgclose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    spLocation.setSelection(0);
                    dialogpopup.dismiss();
                }
            });
            String [] array=null;
            array = new String[1];
            array[0]="SELECT PRODUCT";
            //  mobileno =txtretailermobileno.getText().toString().trim();



            btnPunchIn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        GeneralMaster s1 = (GeneralMaster) sp1.getSelectedItem();
                        GeneralMaster s2 = (GeneralMaster) sp2.getSelectedItem();
                        GeneralMaster s3 = (GeneralMaster) sp3.getSelectedItem();
                        GeneralMaster s4 = (GeneralMaster) sp4.getSelectedItem();
                        GeneralMaster s5 = (GeneralMaster) sp5.getSelectedItem();
                        GeneralMaster s6 = (GeneralMaster) sp6.getSelectedItem();
                        GeneralMaster s7 = (GeneralMaster) sp7.getSelectedItem();
                        if(s1.Code().contains("0"))
                        {
                            ((TextView) sp1.getSelectedView()).setError("Please select answer");
                           // msclass.showMessage("Please select option of Question 1");
                           // return;
                        }
                        if(s2.Code().contains("0"))
                        {
                            ((TextView) sp2.getSelectedView()).setError("Please select answer");
                            // msclass.showMessage("Please select option of Question 1");
                           // return;
                        }

                        if(s3.Code().contains("0"))
                        {
                            ((TextView) sp3.getSelectedView()).setError("Please select answer");
                            // msclass.showMessage("Please select option of Question 1");
                           // return;
                        }
                        if(s4.Code().contains("0"))
                        {
                            ((TextView) sp4.getSelectedView()).setError("Please select answer");
                            // msclass.showMessage("Please select option of Question 1");
                           // return;
                        }

                        if(s5.Code().contains("0"))
                        {
                            ((TextView) sp5.getSelectedView()).setError("Please select answer");
                            // msclass.showMessage("Please select option of Question 1");
                           // return;
                        }

                        if(s1.Code().contains("0"))
                        {
                            ((TextView) sp1.getSelectedView()).setError("Please select answer");
                            // msclass.showMessage("Please select option of Question 1");
                           // return;
                        }

                        if(s6.Code().contains("0"))
                        {
                            ((TextView) sp6.getSelectedView()).setError("Please select answer");
                            // msclass.showMessage("Please select option of Question 1");
                           // return;
                        }
                        if(s7.Code().contains("0"))
                        {
                            ((TextView) sp7.getSelectedView()).setError("Please select answer");
                            // msclass.showMessage("Please select option of Question 1");
                            //return;
                        }

                        if (s1.Code().contains("0") || s2.Code().contains("0") ||
                                s3.Code().contains("0")|| s4.Code().contains("0") ||
                                s5.Code().contains("0")||s6.Code().contains("0")||
                                s7.Code().contains("0"))
                        {
                             msclass.showMessage("Please select  answer .");
                            return;
                        }
                        if(!chk.isChecked())

                        {
                            //chk.setButtonDrawable(getResources().getDrawable(
                                 //   R.drawable.border_style));
                                msclass.showMessage("Please select  declaration check box .");
                            // msclass.showMessage("Please select option of Question 1");
                            return;
                        }

                        savePUNCHINdata(s1.Code().toString(),s2.Code().toString(),s3.Code().toString(),
                                s4.Code().toString(),s5.Code().toString(),s6.Code().toString(),s7.Code().toString());
                        // call Save Retailer Api
                       /* if (spState.getSelectedItem().toString().toLowerCase().equals("select state")) {
                            msclass.showMessage("Please select state");
                            return ;
                        }
                        if (spDist.getSelectedItem().toString().toLowerCase().equals("select district")) {
                            msclass.showMessage("Please select district");
                            return ;
                        }
                        if (spTaluka.getSelectedItem().toString().toLowerCase().equals("select taluka")) {
                            msclass.showMessage("Please Select Taluka");
                            return ;
                        }
                        if (txtretailername.getText().length()==0) {
                            msclass.showMessage("Please  enter retailer name ");
                            return;
                        }
                        if (txtretailerfirmname.getText().length()==0) {
                            msclass.showMessage("Please  enter retailer firm name ");
                            return;
                        }
                        if (txtretailermobileno.getText().length()==0) {
                            msclass.showMessage("Please  enter retailer mobile number  ");
                            return;
                        }
                        if (txtretailermobileno.getText().length() != 10) {
                            Utility.showAlertDialog("Info", "Please Enter Valid Mobile Number", context);
                            return ;
                        }
                        if (txtMarketPlace.getText().length()==0) {
                            Utility.showAlertDialog("Info", "Please Enter market place", context);
                            return ;
                        }

                        retailerfirmname =txtretailerfirmname.getText().toString().trim();
                        RetailerName=txtretailername.getText().toString().trim();
                        mobileno =txtretailermobileno.getText().toString().trim();
                        marketplace =txtMarketPlace.getText().toString().trim();
                        String str= addPOGretaill();
                        if (str.contains("True"))
                        {
                            txtretailername.setText("");
                            txtretailermobileno.setText("");
                            txtretailerfirmname.setText("");
                            txtMarketPlace.setText("");
                            msclass.showMessage("New retailer data saved successfully");
                            BindRetailerList_online(str);
                        }
                        else
                        {
                            msclass.showMessage(str.replace("\"",""));
                        }
                        */


                       /* final String status = spstatus.getSelectedItem().toString();
                        int count = 0;
                        String product = "";
                        if (status.equals("SELECT STATUS")) {
                            msclass.showMessage("Please select stock  status");
                            return;
                        }
                        if (txtqty.getText().length()==0) {
                            msclass.showMessage("Please  enter qty");
                            return;
                        }


                        if (status.contains("SALES RETURN") )
                        {
                            if (Integer.valueOf(txtqty.getText().toString())>Integer.valueOf(txtbalance.getText().toString()))
                            {
                                msclass.showMessage("Sales return ,not allow to more than balance qty.");
                                return;
                            }
                        }
                        if (txtdate.getText().length()==0) {
                            msclass.showMessage("Please  enter date");
                            return;
                        }
                        if (spdistr.getSelectedStrings().contains("SELECT DISTRIBUTOR")) {
                            msclass.showMessage("Please  enter distributor");
                            return;
                        }
                        */
                        //St

                        //SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        // Date d = new Date();
                        //final String strdate = dateFormat.format(d);




                        //ene

                       /* if (count > 0) {
                            msclass.showMessage("product detail added successfully.");
                            dialog.dismiss();

                        } else {
                            msclass.showMessage("Please enter product details");
                        }
  */

                    } catch (Exception ex) {
                        ex.printStackTrace();
                        msclass.showMessage(ex.toString());

                    }
                }
            });

            dialogpopup.show();
            dialogpopup.setCancelable(true);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(dialogpopup.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.gravity = Gravity.CENTER;
            dialogpopup.getWindow().setAttributes(lp);
            //Window window = dialog.getWindow();
            //window.setLayout(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);


        } catch (Exception ex)
        {
            msclass.showMessage(ex.getMessage());
            ex.printStackTrace();

        }



    }
    public void savePUNCHINdata(final String Q1,final String Q2,final String Q3,final String Q4,final String Q5,final String Q6,final String Q7)
    {
        final MediaPlayer MP = MediaPlayer.create(this, R.raw.mahyco);
        if (validation() == true) {

            GeneralMaster pp = (GeneralMaster) spLocation.getSelectedItem();

            if(pp.Code()=="0")
            {
                msclass.showMessage("Please select work location");
                return;
            }
            try {
                AlertDialog.Builder builder = new AlertDialog.Builder(punch.this);

                builder.setTitle("Mahyco");
                // builder.setMessage("Observation Saved");
                builder.setMessage("Do you want to save record?");

                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                    @SuppressLint("WrongConstant")
                    public void onClick(DialogInterface dialog, int which) {

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String entrydate = sdf.format(new Date());

                        SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm:ss");
                        String entrytime = sdf1.format(new Date());

                        String input = txtDate.getText().toString();
                        String Time = txtTime.getText().toString();
                        String cordinate = txtCordinate.getText().toString();

                        String[] split = input.split("Date: ");
                        String Date = split[1];

                        String[] split1 = Time.split("Time: ");
                        String TimeSplit = split1[1];

                        String[] cordi = cordinate.split("Cordinates: ");
                        String cordinates = cordi[1];

                        boolean result = databaseHelper1.InsertPunchData(userCode, txtLocation.getText().toString(), cordinates,
                                "IN", Date, entrytime, entrydate);
                        databaseHelper1.InserthealthData(userCode,Q1,Q2,Q3,Q4,Q5,Q6,Q7,"0",Date);
                        if (result) {
                            MP.start();
                            msclass.showMessage("Punch IN data save successfully");
                            mainlayout.setBackgroundColor(Color.rgb(255, 76, 76));
                            btnPunchOUT.setVisibility(View.VISIBLE);
                            btnClick.setVisibility(View.GONE);
                            worklinerId.setVisibility(View.GONE);
                            dialogpopup.dismiss();
                            updateUI();
                            dialog.dismiss();
                            showdata();

                            if (CheckNetwork.isInternetAvailable(punch.this)) //returns true if internet available
                            {
                                HR_Data_Upload("HR_Data_UploadNew");

                                //do something. loadwebview.
                            } else {
                                // Toast.makeText(punch.this,"No Internet Connection",1000).show();
                            }

                        }
                    }
                });

                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        // Do nothing
                        dialog.dismiss();
                    }
                });

                AlertDialog alert = builder.create();
                alert.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    private  void BindIntialData() {

        try {
            spLocation.setAdapter(null);
            //List<GeneralMaster> Croplist = new ArrayList<GeneralMaster>();
            List<GeneralMaster> Croplist = new ArrayList<GeneralMaster>();
            Croplist.add(new GeneralMaster("0", "SELECT WORK LOCATION"));
            Croplist.add(new GeneralMaster("1", "WORK FROM HOME"));
            Croplist.add(new GeneralMaster("2", "WORK FROM OFFICE/FIELD/PLANT/DEPOT"));

            ArrayAdapter<GeneralMaster> adapter = new ArrayAdapter<GeneralMaster>
                    (this, android.R.layout.simple_spinner_dropdown_item, Croplist);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spLocation.setAdapter(adapter);




        }
        catch (Exception ex) {
            Toast.makeText(context, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }


    }

    private void getCurrentVersion() {
        PackageManager pm = this.getPackageManager();
        PackageInfo pInfo = null;

        try {
            pInfo = pm.getPackageInfo(this.getPackageName(), 0);

        } catch (PackageManager.NameNotFoundException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        currentVersion = pInfo.versionName;

        new GetLatestVersion().execute();
    }



    private class GetLatestVersion extends AsyncTask<String, String, JSONObject> {

        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected JSONObject doInBackground(String... params) {
            try {
//It retrieves the latest version by scraping the content of current version from play store at runtime
                String urlOfAppFromPlayStore = "https://play.google.com/store/apps/details?id=com.mahyco.time.timemanagement";
                Document doc = Jsoup.connect(urlOfAppFromPlayStore).get();
                latestVersion = doc.getElementsByClass("htlgb").get(6).text();

            } catch (Exception e) {
                e.printStackTrace();

            }

            return new JSONObject();
        }

        @Override
        protected void onPostExecute(JSONObject jsonObject) {
            if (latestVersion != null) {
                if (!currentVersion.equalsIgnoreCase(latestVersion)) {
                    if (!isFinishing()) { //This would help to prevent Error : BinderProxy@45d459c0 is not valid; is your activity running? error
                        showUpdateDialog();
                    } else {
//                        new Thread(new Runnable() {
//                            @Override
//                            public void run() {
//                                dowork();
//                                startapp();
//                                finish();
//                            }
//                        }).start();

                    }
                }
            } else
                // background.start();
                super.onPostExecute(jsonObject);
        }
    }

    private void showUpdateDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("A New Update is Available");
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse
                        ("https://play.google.com/store/apps/details?id=com.mahyco.time.timemanagement")));
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //background.start();
            }
        });

        builder.setCancelable(false);
        dialog1 = builder.show();
    }
    public static void setBlinkingTextview(ImageView tv, long milliseconds, long offset) {
        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(milliseconds); //You can manage the blinking time with this parameter
        anim.setStartOffset(offset);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        tv.startAnimation(anim);
    }
    public void showdata() {
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String formattedDate = df.format(c);
        Cursor data = databaseHelper1.Data();
        worklinerId.setVisibility(View.VISIBLE);
        if (data.getCount() == 0) {
            // msclass.showMessage("No Data Available... ");
        } else {
            data.moveToFirst();
            if (data != null) {
                try {


                    do {
                        txtDate1.setText("Date   :  " + (data.getString(data.getColumnIndex("punchdate"))));
                        txtTime1.setText("Time   :  " + (data.getString(data.getColumnIndex("punchtime"))));
                        txtFlag1.setText("In/Out :  " + (data.getString(data.getColumnIndex("att_flag"))) + "\n");

                        String lastdate = (data.getString(data.getColumnIndex("punchdate")));

                        if ((data.getString(data.getColumnIndex("att_flag"))).equals("IN")) {
                            mainlayout.setBackgroundColor(Color.rgb(255, 76, 76));
                            btnPunchOUT.setVisibility(View.VISIBLE);
                            btnClick.setVisibility(View.GONE);
                            worklinerId.setVisibility(View.GONE);
                            updateUI();
                        } else if ((data.getString(data.getColumnIndex("att_flag"))).equals("OUT")) {
                            mainlayout.setBackgroundColor(Color.rgb(76, 166, 76));
                            btnPunchOUT.setVisibility(View.GONE);
                            btnClick.setVisibility(View.VISIBLE);
                            worklinerId.setVisibility(View.VISIBLE);
                            updateUI();
                        } else {
                            //
                        }

                        if (lastdate.equals(formattedDate))
                        {
                           // worklinerId.setVisibility(View.GONE);
                              //New Code  add
                            if ((data.getString(data.getColumnIndex("att_flag"))).equals("IN")) {
                                mainlayout.setBackgroundColor(Color.rgb(255, 76, 76));
                                btnPunchOUT.setVisibility(View.VISIBLE);
                                btnClick.setVisibility(View.GONE);
                                worklinerId.setVisibility(View.GONE);
                                updateUI();
                            } else if ((data.getString(data.getColumnIndex("att_flag"))).equals("OUT")) {
                                mainlayout.setBackgroundColor(Color.rgb(76, 166, 76));
                                btnPunchOUT.setVisibility(View.GONE);
                                btnClick.setVisibility(View.VISIBLE);
                                worklinerId.setVisibility(View.VISIBLE);
                                updateUI();
                            } else {
                                //
                            }
                             //new code end



                        } else {
                            mainlayout.setBackgroundColor(Color.rgb(76, 166, 76));
                            btnPunchOUT.setVisibility(View.GONE);
                            btnClick.setVisibility(View.VISIBLE);
                            worklinerId.setVisibility(View.VISIBLE);
                            updateUI();
                        }
                    } while (data.moveToNext());

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
            data.close();
        }
    }

    private boolean validation() {
        boolean flag = true;
        if (txtCordinate.getText().equals("")) {
            msclass.showMessage("Poor GPS connectivity\nTry again later!");
            return false;
        }
        if (txtLocation.getText().equals("")) {
            msclass.showMessage("Poor GPS connectivity\nTry again later!");
            return false;
        }

        return true;
    }

    @SuppressLint("RestrictedApi")
    protected void createLocationRequest() {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(INTERVAL);
        mLocationRequest.setSmallestDisplacement(10);
        mLocationRequest.setFastestInterval(FASTEST_INTERVAL);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    public static boolean isTimeAutomatic(Context c) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return Settings.Global.getInt(c.getContentResolver(), Settings.Global.AUTO_TIME, 0) == 1;
        } else {
            return android.provider.Settings.System.getInt(c.getContentResolver(), android.provider.Settings.System.AUTO_TIME, 0) == 1;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart fired ..............");
        mGoogleApiClient.connect();
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop fired ..............");
        mGoogleApiClient.disconnect();
        Log.d(TAG, "isConnected ...............: " + mGoogleApiClient.isConnected());
    }

    @Override
    public void onConnected(Bundle bundle) {

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                .addLocationRequest(mLocationRequest);
        builder.setAlwaysShow(true);
        PendingResult result =
                LocationServices.SettingsApi.checkLocationSettings(
                        mGoogleApiClient,
                        builder.build()
                );

        result.setResultCallback(this);

        Log.d(TAG, "onConnected - isConnected ...............: " + mGoogleApiClient.isConnected());
        startLocationUpdates();
    }

    @Override
    public void onResult(@NonNull Result result) {
        final Status status = result.getStatus();
        switch (status.getStatusCode()) {
            case LocationSettingsStatusCodes.SUCCESS:

                // NO need to show the dialog;

                break;

            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                //  Location settings are not satisfied. Show the user a dialog

                try {
                    // Show the dialog by calling startResolutionForResult(), and check the result
                    // in onActivityResult().

                    status.startResolutionForResult(punch.this, REQUEST_CHECK_SETTINGS);

                } catch (IntentSender.SendIntentException e) {

                    //failed to show
                }
                break;

            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                // Location settings are unavailable so not possible to show any dialog now
                break;
        }
    }
   // @Override
   // public void onResult(@NonNull LocationSettingsResult locationSettingsResult) {

    //}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == KeyEvent.KEYCODE_BACK) {
            if(null != dialogpopup)
                dialogpopup.dismiss();
            spLocation.setSelection(0);
        }

        if (requestCode == REQUEST_CHECK_SETTINGS) {

            if (resultCode == RESULT_OK) {

                Toast.makeText(getApplicationContext(), "GPS enabled", Toast.LENGTH_LONG).show();
            } else {

                Toast.makeText(getApplicationContext(), "GPS is not enabled", Toast.LENGTH_LONG).show();
            }

        }
    }
    protected void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
         PendingResult<Status> pendingResult = LocationServices.FusedLocationApi.requestLocationUpdates(
                mGoogleApiClient, mLocationRequest, this);
        //Task<Void> pendingResult = fusedLocationClient.requestLocationUpdates(mLocationRequest,mlocationCallback, null);
        Log.d(TAG, "Location update started ..............: ");

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.d(TAG, "Connection failed: " + connectionResult.toString());
    }

    @Override
    public void onLocationChanged(Location location) {
        Log.d(TAG, "Firing onLocationChanged..............................................");
        mCurrentLocation = location;
        mLastUpdateTime = DateFormat.getTimeInstance().format(new Date());
      float accuracy=  mCurrentLocation.getAccuracy();

      if(accuracy==0.0f){


          txtAccuracy.setText( String.valueOf(accuracy));
          txtAccuracy.setVisibility(View.INVISIBLE);
          txtAccuracyTxt.setVisibility(View.INVISIBLE);


      }else {


          txtAccuracy.setText( accuracy+"m");
          txtAccuracy.setVisibility(View.VISIBLE);
          txtAccuracyTxt.setVisibility(View.VISIBLE);
      }



        // mDate=DateFormat.getDateInstance().format(new Date());
       // mDate = getDateFromTimeStamp(location.getTime());
        Date c = Calendar.getInstance().getTime();
       // System.out.println("Current time => " + c);

        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String formattedDate = df.format(c);

        SimpleDateFormat sdfm = new SimpleDateFormat("EEEE");

        Date d = new Date();
        String day=sdfm.format(d);
        mDay=day;
        mDate=formattedDate;
        updateUI();
    }


    private void updateUI() {
        Log.d(TAG, "UI update initiated .............");
        if (null != mCurrentLocation) {
            String lat = String.valueOf(mCurrentLocation.getLatitude());
            String lng = String.valueOf(mCurrentLocation.getLongitude());
            txtDate.setText("Date: " + mDate);
            txtDay.setText("Day: " + mDay);
            txtTime.setText("Time: " + mLastUpdateTime);
            txtCordinate.setText("Cordinates: " + lat + "," + lng);

            try {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocation(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude(), 1);
                txtLocation.setText("" + addresses.get(0).getAddressLine(0) + "");
            } catch (Exception e) {

            }
        } else {
            Log.d(TAG, "location is null ...............");
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopLocationUpdates();
    }

    protected void stopLocationUpdates() {
        LocationServices.FusedLocationApi.removeLocationUpdates(
                mGoogleApiClient, this);
        Log.d(TAG, "Location update stopped .......................");
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mGoogleApiClient.isConnected()) {
            startLocationUpdates();
            Log.d(TAG, "Location update resumed .....................");
        }
    }

    private boolean isGooglePlayServicesAvailable() {

        int status = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(this);
        if (ConnectionResult.SUCCESS == status) {
            return true;
        } else {
            GooglePlayServicesUtil.getErrorDialog(status, this, 0).show();
            return false;
        }
    }

    public void onProviderDisabled(String provider) {
        Toast.makeText(this, "Please Enable GPS", Toast.LENGTH_SHORT).show();
        final Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(intent);
    }

    // To Upload Obseervation On server
    public   void HR_Data_Upload(String HR_Data_UploadNew)
    {
        if(config.NetworkConnection()) {
            dialog.setMessage("Loading....");
            dialog.show();
            String str= null;
            // str = cx.new MDOMasterData(1, txtUsername.getText().toString(), txtPassword.getText().toString()).execute().get();
            String searchQuery = "select  *  from punchdata where flag='0' LIMIT 1";
            String searchQuery2 = "select  *  from healthTable where att_flag='0' LIMIT 1 ";
            Cursor cursor = databaseHelper1.getReadableDatabase().rawQuery(searchQuery, null );
            int count=cursor.getCount();
            cursor.close();
            if (count > 0) {

                try {
                    byte[] objAsBytes = null;//new byte[10000];
                    JSONObject object = new JSONObject();
                    try {
                        object.put("Table1", databaseHelper1.getResults(searchQuery));
                        object.put("Table2", databaseHelper1.getResults(searchQuery2));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        objAsBytes = object.toString().getBytes("UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    dialog.setMessage("Loading. Please wait...");
                    dialog.show();
                   // str= new UploadDataServer(HR_Data_Upload,objAsBytes).execute(SERVER).get();
                    new UploadDataServer(HR_Data_UploadNew,objAsBytes).execute(SERVER);
                    //End
                   // cursor.close();
                    //End
                   /* if(str.contains("True")) {

                        dialog.dismiss();
                       // msclass.showMessage("Records Uploaded successfully");
                        String searchQuery1 = "update punchdata set flag = '1' where flag='0'";


                        databaseHelper1.runQuery(searchQuery1);
                    }
                    else
                    {
                        msclass.showMessage(str);
                        dialog.dismiss();
                    }*/

                }
                catch (Exception ex)
                {   dialog.dismiss();
                    msclass.showMessage(ex.getMessage());


                }
            }
            else
            {   dialog.dismiss();
                //msclass.showMessage("Data not available for Uploading ");
                dialog.dismiss();

            }

        }
        else
        {
            //msclass.showMessage("Internet network not available.");
            dialog.dismiss();
        }
        //dialog.dismiss();
    }
    //
    public synchronized String sycuploadHrData(JSONObject jsonObject) {

        return HttpUtils.POSTJSON(Constants.HR_Data_Upload,jsonObject,
                mPref.getString(AppConstant.ACCESS_TOKEN_TAG,""));
    }
    public  String  uploadHrData(String encodeImage)
    {
        String str="";
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonObjectreq = new JSONObject();
        try {
            jsonObjectreq.put("encodedData",encodeImage);
            jsonObject.put("Table",jsonObjectreq);
            str= sycuploadHrData(jsonObject);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return str;

    }
    public class UploadDataServer extends AsyncTask<String, String, String> {

        byte[] objAsBytes;
        String Imagestring1;
        String Imagestring2;
        String ImageName;
        String Funname;
        public UploadDataServer( String Funname, byte[] objAsBytes) {

            //this.IssueID=IssueID;
            this.objAsBytes=objAsBytes;
            this.Imagestring1 =Imagestring1;
            this.Imagestring2 =Imagestring2;
            this.ImageName=ImageName;
            this.Funname=Funname;

        }
        protected void onPreExecute() {}
        @Override
        protected String doInBackground(String... urls) {

            String encodeImage = Base64.encodeToString(objAsBytes,Base64.DEFAULT);
            return uploadHrData(encodeImage);
            // encode image to base64 so that it can be picked by saveImage.php file


        }
        protected void onPostExecute(String result) {
            String weatherInfo="Weather Report  is: \n";
            try{
                dialog.dismiss();
                String resultout=result.trim();
                if(resultout.contains("True")) {
                    // msclass.showMessage("Data uploaded successfully.");

                    if(Funname.equals("HR_Data_UploadNew")) {

                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        Date d=new Date();
                        String strdate=dateFormat.format(d);

                        dialog.dismiss();
                        // msclass.showMessage("Records Uploaded successfully");
                        String searchQuery1 = "update punchdata set flag = '1' where flag='0'";
                        String searchQuery2 = "update healthTable set att_flag = '1' where att_flag='0'";

                        databaseHelper1.runQuery(searchQuery1);
                        databaseHelper1.runQuery(searchQuery2);
                    }

                }
                else
                {
                    msclass.showMessage(result+"error");
                }

                // dialog.dismiss();


            }

            catch (Exception e) {
                e.printStackTrace();
                msclass.showMessage(e.getMessage().toString());
                dialog.dismiss();
            }

        }
    }

    public static class CheckNetwork {


        private static final String TAG = CheckNetwork.class.getSimpleName();
        public static boolean isInternetAvailable(Context context)
        {
            NetworkInfo info = (NetworkInfo) ((ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();

            if (info == null)
            {
                Log.d(TAG,"no internet connection");
                return false;
            }
            else
            {
                if(info.isConnected())
                {
                    Log.d(TAG," internet connection available...");
                    return true;
                }
                else
                {
                    Log.d(TAG," internet connection");
                    return true;
                }

            }
        }
    }
}
