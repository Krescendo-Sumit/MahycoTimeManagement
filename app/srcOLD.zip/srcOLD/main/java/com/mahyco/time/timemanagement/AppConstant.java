package com.mahyco.time.timemanagement;

public class AppConstant {

    public static String ACCESS_TOKEN_TAG="ACCESSTOKEN";
    public static String USER_CODE_TAG="USERCODE";
}
