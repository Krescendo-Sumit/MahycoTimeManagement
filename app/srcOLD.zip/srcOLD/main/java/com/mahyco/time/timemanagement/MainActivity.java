package com.mahyco.time.timemanagement;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    databaseHelper databaseHelper1;
    public android.widget.ProgressBar mprogresss;

    SharedPreferences pref;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pref = getApplicationContext().getSharedPreferences("MyPref", 0); // 0 - for private mode
        editor = pref.edit();
        databaseHelper1=new databaseHelper(this);

        new Thread(new Runnable() {
            @Override
            public void run() {
                dowork();
                startapp();
                finish();
            }
        }).start();
    }
    private void dowork(){

        for (int progress=0;progress<100;progress+=10)
        {
            try
            {
                Thread.sleep(100);//300
                mprogresss.setProgress(progress);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

        }
    }

    private void startapp()
    {

        if (pref.getString("UserID", null) != null||pref.getString("USER_EMAIL", null) != null) {
            Intent intent = new Intent(this, punch.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }else {
            Intent intent = new Intent(this, login.class);
            startActivity(intent);
        }
        //Intent intent= new Intent(this,login.class);
       // startActivity(intent);
    }
}
