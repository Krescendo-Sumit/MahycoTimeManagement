package com.mahyco.time.timemanagement;

public class Constants {



    public  static String GetToken="https://gisccf.mahyco.com/token";
    public static  String  HR_VerifyUser="https://gisccf.mahyco.com/api/hrbreaderdata/HR_VerifyUser";;
    public static String HR_Data_Upload="https://gisccf.mahyco.com/api/hrbreaderdata/HR_Data_Upload";
}
